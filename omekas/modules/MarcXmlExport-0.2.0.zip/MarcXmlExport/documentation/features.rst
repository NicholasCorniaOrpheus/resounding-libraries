Features
========

To retrieve your file or view previous exports, go to the past exports page.

(Admin > Export Marc Xml > Past exports)

.. image:: images/MarcXMLExport_past-exports.png

On this page you'll find a summary of the export details and the list of exported resources (provided they're still in the database).
And, of course, you can download the resulting file.

Also you can see to the tutorial section:
:doc:`tutorials`