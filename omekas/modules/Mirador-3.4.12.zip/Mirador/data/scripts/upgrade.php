<?php declare(strict_types=1);

namespace Mirador;

use Omeka\Stdlib\Message;

/**
 * @var Module $this
 * @var \Laminas\ServiceManager\ServiceLocatorInterface $services
 * @var string $newVersion
 * @var string $oldVersion
 *
 * @var \Omeka\Api\Manager $api
 * @var \Omeka\Settings\Settings $settings
 * @var \Doctrine\DBAL\Connection $connection
 * @var \Doctrine\ORM\EntityManager $entityManager
 * @var \Omeka\Mvc\Controller\Plugin\Messenger $messenger
 */
$plugins = $services->get('ControllerPluginManager');
$api = $plugins->get('api');
$settings = $services->get('Omeka\Settings');
$connection = $services->get('Omeka\Connection');
$messenger = $plugins->get('messenger');
$entityManager = $services->get('Omeka\EntityManager');

if (!method_exists($this, 'checkModuleActiveVersion') || !$this->checkModuleActiveVersion('Common', '3.4.78')) {
    $message = new Message(
        'The module %1$s should be upgraded to version %2$s or later.', // @translate
        'Common', '3.4.78'
    );
    throw new \Omeka\Module\Exception\ModuleCannotInstallException((string) $message);
}

if (version_compare($oldVersion, '3.1.0', '<')) {
    $sql = <<<'SQL'
        DELETE FROM site_setting
        WHERE id IN ('mirador_class', 'mirador_style', 'mirador_locale');
        SQL;
    $connection->executeStatement($sql);
}

if (version_compare($oldVersion, '3.1.3', '<')) {
    $sql = <<<'SQL'
        DELETE FROM site_setting
        WHERE id IN ("mirador_append_item_set_show", "mirador_append_item_show", "mirador_append_item_set_browse", "mirador_append_item_browse");
        SQL;
    $connection->executeStatement($sql);
}

if (version_compare($oldVersion, '3.1.7', '<')) {
    $siteSettings = $services->get('Omeka\Settings\Site');
    $sites = $api->search('sites')->getContent();
    foreach ($sites as $site) {
        $siteSettings->setTargetId($site->id());
        $siteSettings->set('mirador_version', '2');
    }
}

if (version_compare($oldVersion, '3.3.7.3', '<')) {
    $settings->delete('mirador_manifest_property');
}

if (version_compare($oldVersion, '3.3.7.9', '<')) {
    $settings->set('mirador_plugins_2', $settings->get('mirador_plugins', []));
    $settings->set('mirador_plugins', []);
    $settings->set('mirador_config_item_2', $settings->get('mirador_config_item', null));
    $settings->set('mirador_config_item', null);
    $settings->set('mirador_config_collection_2', $settings->get('mirador_config_collection', null));
    $settings->set('mirador_config_collection', null);

    $siteSettings = $services->get('Omeka\Settings\Site');
    $sites = $api->search('sites')->getContent();
    foreach ($sites as $site) {
        $siteSettings->setTargetId($site->id());
        $siteSettings->set('mirador_plugins_2', $siteSettings->get('mirador_plugins', []));
        $siteSettings->set('mirador_plugins', []);
        $siteSettings->set('mirador_config_item_2', $siteSettings->get('mirador_config_item', null));
        $siteSettings->set('mirador_config_item', null);
        $siteSettings->set('mirador_config_collection_2', $siteSettings->get('mirador_config_collection', null));
        $siteSettings->set('mirador_config_collection', null);
    }
}

if (version_compare($oldVersion, '3.3.7.13', '<')) {
    $module = $services->get('Omeka\ModuleManager')->getModule('IiifServer');
    if ($module && version_compare($module->getIni('version') ?? '', '3.6.5.3', '<')) {
        $translator = $services->get('MvcTranslator');
        $message = new \Omeka\Stdlib\Message(
            $translator->translate('This module requires the module "%s", version %s or above.'), // @translate
            'IiifServer', '3.6.5.3'
        );
        throw new \Omeka\Module\Exception\ModuleCannotInstallException((string) $message);
    }

    $message = new Message(
        'The module supports audio and video for Mirador v3.' // @translate
    );
    $messenger->addSuccess($message);
}

if (version_compare($oldVersion, '3.4.11', '<')) {
    $settings->set('mirador_plugins_3', $settings->get('mirador_plugins', []));
    $settings->set('mirador_plugins', []);
    $settings->set('mirador_config_item_3', $settings->get('mirador_config_item', null));
    $settings->set('mirador_config_item', null);
    $settings->set('mirador_config_collection_3', $settings->get('mirador_config_collection', null));
    $settings->set('mirador_config_collection', null);

    $siteSettings = $services->get('Omeka\Settings\Site');
    $sites = $api->search('sites')->getContent();
    foreach ($sites as $site) {
        $siteSettings->setTargetId($site->id());
        $siteSettings->set('mirador_plugins_3', $siteSettings->get('mirador_plugins', []));
        $siteSettings->set('mirador_plugins', []);
        $siteSettings->set('mirador_config_item_3', $siteSettings->get('mirador_config_item', null));
        $siteSettings->set('mirador_config_item', null);
        $siteSettings->set('mirador_config_collection_3', $siteSettings->get('mirador_config_collection', null));
        $siteSettings->set('mirador_config_collection', null);
    }

    $message = new Message(
        'The module supports Mirador v4.' // @translate
    );
    $messenger->addSuccess($message);

    $message = new Message(
        'Warning: if you customized theme, note that settings were renamed.' // @translate
    );
    $messenger->addWarning($message);
}

if (version_compare($oldVersion, '3.4.12', '<')) {
    $message = new Message(
        'Mirador v4 now uses ecmascript modules with import maps instead of pre-compiled bundles. Plugins are now loaded individually and locally, in a GDPR-compliand way.' // @translate
    );
    $messenger->addSuccess($message);
}
