<?php declare(strict_types=1);

namespace BulkImport\Reader;

use BulkImport\Entry\BaseEntry;
use BulkImport\Entry\Entry;
use BulkImport\Interfaces\Configurable;
use BulkImport\Interfaces\Parametrizable;
use BulkImport\Traits\ConfigurableTrait;
use BulkImport\Traits\ParametrizableTrait;
use BulkImport\Traits\ServiceLocatorAwareTrait;
use Common\Stdlib\PsrMessage;
use Laminas\Form\Form;
use Laminas\Log\Logger;
use Laminas\ServiceManager\ServiceLocatorInterface;

/**
 * Reader implements Iterator and Countable.
 */
abstract class AbstractReader implements Reader, Configurable, Parametrizable
{
    // TODO Remove these traits so sub reader won't be all configurable.
    use ConfigurableTrait, ParametrizableTrait, ServiceLocatorAwareTrait;

    /**
     * @var int
     */
    const BATCH_SIZE = 100;

    /**
     * @var string
     */
    protected $entryClass = BaseEntry::class;

    /**
     * @var \BulkImport\Mvc\Controller\Plugin\Bulk
     */
    protected $bulk;

    /**
     * @var \BulkImport\Mvc\Controller\Plugin\BulkFile
     */
    protected $bulkFile;

    /**
     * @var \Mapper\Stdlib\Mapper|null
     */
    protected $mapper;

    /**
     * @var \Laminas\Log\Logger
     */
    protected $logger;

    /**
     * This is the base path of the files, not the base path of the url.
     *
     * @var string
     */
    protected $basePath;

    /**
     * @var string
     */
    protected $label;

    /**
     * @var array
     */
    protected $availableFields = [];

    /**
     * @var string
     */
    protected $resourceName;

    /**
     * This is the resource name ("resources", "assets") or the table name.
     *
     * @deprecated
     * @var string
     */
    protected $objectType;

    /**
     * @var array
     */
    protected $filters = [];

    /**
     * @var array
     */
    protected $order = [
        'by' => null,
        'dir' => 'ASC',
    ];

    /**
     * @var string|null
     */
    protected $lastErrorMessage;

    /**
     * @var string
     */
    protected $configFormClass;

    /**
     * @var string
     */
    protected $paramsFormClass;

    /**
     * var array
     */
    protected $configKeys = [];

    /**
     * var array
     */
    protected $paramsKeys = [];

    /**
     * The main iterator to loop on.
     * May be \IteratorIterator, so the index may be a duplicate, so use it in
     * conjunction with the main iterator index when needed.
     *
     * @var \Iterator|\IteratorIterator
     */
    protected $iterator;

    /**
     * @var bool
     */
    protected $isReady = false;

    /**
     * For spreadsheets, the total entries should not include headers.
     *
     * @var int
     */
    protected $totalEntries;

    /**
     * @var mixed
     */
    protected $currentData;

    /**
     * Reader constructor.
     */
    public function __construct(ServiceLocatorInterface $services)
    {
        $this->setServiceLocator($services);
        $config = $services->get('Config');
        $this->basePath = $config['file_store']['local']['base_path'] ?: (OMEKA_PATH . '/files');
        $plugins = $services->get('ControllerPluginManager');
        $this->bulk = $plugins->get('bulk');
        $this->bulkFile = $plugins->get('bulkFile');
        $this->mapper = $services->get('Mapper\Mapper');
    }

    public function getLabel(): string
    {
        return $this->label;
    }

    public function setLogger(Logger $logger): self
    {
        $this->logger = $logger;
        return $this;
    }

    public function isValid(): bool
    {
        if (!$this->lastErrorMessage) {
            return true;
        } elseif ($this->lastErrorMessage instanceof PsrMessage) {
            $this->logger->err($this->lastErrorMessage->getMessage(), $this->lastErrorMessage->getContext());
        } elseif (!is_bool($this->lastErrorMessage)) {
            $this->logger->err($this->lastErrorMessage);
        }
        return false;
    }

    public function getLastErrorMessage(): ?string
    {
        return (string) $this->lastErrorMessage;
    }

    public function getAvailableFields(): array
    {
        $this->isReady();
        return $this->availableFields;
    }

    public function getConfigFormClass(): string
    {
        return $this->configFormClass;
    }

    public function handleConfigForm(Form $form): self
    {
        $values = $form->getData();
        $config = array_intersect_key($values, array_flip($this->configKeys));
        $this->setConfig($config);
        $this->reset();
        return $this;
    }

    public function getParamsFormClass(): string
    {
        return $this->paramsFormClass;
    }

    public function handleParamsForm(Form $form): self
    {
        $values = $form->getData();
        $params = array_intersect_key($values, array_flip($this->paramsKeys));
        $this->setParams($params);
        $this->appendInternalParams();
        $this->reset();
        return $this;
    }

    public function setResourceName(string $resourceName): self
    {
        $this->resourceName = $resourceName;
        // TODO Remove object type.
        $this->objectType = $resourceName;
        return $this;
    }

    public function setFilters(?array $filters): self
    {
        $this->filters = $filters ?? [];
        return $this;
    }

    public function setOrders($by, $dir = 'ASC'): self
    {
        $this->orders = [];
        if (!$by) {
            // Nothing.
        } elseif (is_string($by)) {
            $this->orders[] = [
                'by' => $by,
                'dir' => strtoupper($dir) === 'DESC' ? 'DESC' : 'ASC',
            ];
        } elseif (is_array($by)) {
            foreach ($by as $byElement) {
                $this->orders[] = [
                    'by' => $byElement['by'],
                    'dir' => !empty($byElement['dir']) && strtoupper($byElement['dir']) === 'DESC' ? 'DESC' : 'ASC',
                ];
            }
        }
        return $this;
    }

    #[\ReturnTypeWillChange]
    public function current()
    {
        $this->isReady();
        $this->currentData = $this->iterator->current();
        return $this->currentData
            ? $this->currentEntry()
            : null;
    }

    #[\ReturnTypeWillChange]
    public function key()
    {
        $this->isReady();
        return $this->iterator->key();
    }

    public function next(): void
    {
        $this->isReady();
        $this->iterator->next();
    }

    public function rewind(): void
    {
        $this->isReady();
        $this->iterator->rewind();
    }

    public function valid(): bool
    {
        $this->isReady();
        return $this->iterator->valid();
    }

    public function count(): int
    {
        $this->isReady();
        if ($this->totalEntries === null) {
            $this->totalEntries = method_exists($this->iterator, 'count')
                ? $this->iterator->count()
                : iterator_count($this->iterator);
        }
        return (int) $this->totalEntries;
    }

    /**
     * Get the current data mapped as an Entry, by default for an array.
     */
    protected function currentEntry(): Entry
    {
        $class = $this->entryClass;
        return new $class(
            $this->currentData,
            $this->key(),
            $this->availableFields,
            // TODO Remove mapper.
            $this->getParams() + ['mapper' => $this->mapper]
        );
    }

    /**
     * Check if the reader is ready, or prepare it.
     */
    protected function isReady(): bool
    {
        if ($this->isReady) {
            return true;
        }
        $this->prepareIterator();
        return $this->isReady;
    }

    /**
     * Reset the iterator to allow to use it with different params.
     */
    protected function reset(): self
    {
        $this->availableFields = [];
        $this->objectType = null;
        $this->lastErrorMessage = null;
        $this->isReady = false;
        $this->iterator = null;
        $this->totalEntries = null;
        $this->currentData = null;
        return $this;
    }

    /**
     * To prepare an iterator may be a complex process, because source may be
     * very different and may have various system of pagination.
     *
     * @throws \Omeka\Service\Exception\RuntimeException
     */
    protected function prepareIterator(): self
    {
        // The params should be checked and valid.
        $this->reset();
        if (!$this->isValid()) {
            throw new \Omeka\Service\Exception\RuntimeException((string) $this->getLastErrorMessage());
        }

        $this->initializeReader();
        $this->finalizePrepareIterator();
        $this->prepareAvailableFields();

        $this->isReady = true;
        return $this;
    }

    /**
     * Initialize the reader iterator.
     */
    abstract protected function initializeReader(): self;

    /**
     * Called only by prepareIterator() after opening reader.
     */
    protected function finalizePrepareIterator(): self
    {
        if ($this->iterator !== null) {
            $this->totalEntries = iterator_count($this->iterator);
            $this->iterator->rewind();
        }
        return $this;
    }

    /**
     * The list of available fields are an array.
     */
    protected function prepareAvailableFields(): self
    {
        return $this;
    }

    /**
     * Prepare other internal data.
     */
    protected function appendInternalParams(): self
    {
        $services = $this->getServiceLocator();
        $settings = $services->get('Omeka\Settings');

        $internalParams = [];
        $internalParams['iiifserver_media_api_url'] = $settings->get('iiifserver_media_api_url', '');
        if ($internalParams['iiifserver_media_api_url']
            && mb_substr($internalParams['iiifserver_media_api_url'], -1) !== '/'
        ) {
            $internalParams['iiifserver_media_api_url'] .= '/';
        }

        $this->setParams(array_merge($this->getParams() + $internalParams));

        return $this;
    }
}
