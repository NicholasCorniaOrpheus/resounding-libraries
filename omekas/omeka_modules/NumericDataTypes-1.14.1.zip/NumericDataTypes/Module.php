<?php
namespace NumericDataTypes;

use Composer\Semver\Comparator;
use Doctrine\Common\Collections\Criteria;
use Omeka\Module\AbstractModule;
use Laminas\EventManager\Event;
use Laminas\EventManager\SharedEventManagerInterface;
use Laminas\ServiceManager\ServiceLocatorInterface;

class Module extends AbstractModule
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function install(ServiceLocatorInterface $services)
    {
        $sql = <<<'SQL'
CREATE TABLE numeric_data_types_integer (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value NUMERIC(32, 16) NOT NULL, INDEX IDX_6D39C79089329D25 (resource_id), INDEX IDX_6D39C790549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
CREATE TABLE numeric_data_types_duration (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value BIGINT NOT NULL, INDEX IDX_E1B5FC6089329D25 (resource_id), INDEX IDX_E1B5FC60549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
CREATE TABLE numeric_data_types_timestamp (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value BIGINT NOT NULL, INDEX IDX_7367AFAA89329D25 (resource_id), INDEX IDX_7367AFAA549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
CREATE TABLE numeric_data_types_interval (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value BIGINT NOT NULL, value2 BIGINT NOT NULL, INDEX IDX_7E2C936B89329D25 (resource_id), INDEX IDX_7E2C936B549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB;
ALTER TABLE numeric_data_types_integer ADD CONSTRAINT FK_6D39C79089329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_integer ADD CONSTRAINT FK_6D39C790549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_duration ADD CONSTRAINT FK_E1B5FC6089329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_duration ADD CONSTRAINT FK_E1B5FC60549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_timestamp ADD CONSTRAINT FK_7367AFAA89329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_timestamp ADD CONSTRAINT FK_7367AFAA549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_interval ADD CONSTRAINT FK_7E2C936B89329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;
ALTER TABLE numeric_data_types_interval ADD CONSTRAINT FK_7E2C936B549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;
SQL;
        $conn = $services->get('Omeka\Connection');
        $conn->exec($sql);
    }

    public function uninstall(ServiceLocatorInterface $services)
    {
        $conn = $services->get('Omeka\Connection');
        $conn->exec('DROP TABLE IF EXISTS numeric_data_types_duration;');
        $conn->exec('DROP TABLE IF EXISTS numeric_data_types_integer;');
        $conn->exec('DROP TABLE IF EXISTS numeric_data_types_timestamp;');
        $conn->exec('DROP TABLE IF EXISTS numeric_data_types_interval;');
    }

    public function upgrade($oldVersion, $newVersion, ServiceLocatorInterface $services)
    {
        $conn = $services->get('Omeka\Connection');
        if (Comparator::lessThan($oldVersion, '1.1.0-alpha')) {
            $conn->exec('CREATE TABLE numeric_data_types_interval (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value BIGINT NOT NULL, value2 BIGINT NOT NULL, INDEX IDX_7E2C936B89329D25 (resource_id), INDEX IDX_7E2C936B549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB;');
            $conn->exec('ALTER TABLE numeric_data_types_interval ADD CONSTRAINT FK_7E2C936B89329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;');
            $conn->exec('ALTER TABLE numeric_data_types_interval ADD CONSTRAINT FK_7E2C936B549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;');
        }
        if (Comparator::lessThan($oldVersion, '1.2.0')) {
            // The numeric_data_types_duration table was mistakenly not created
            // in the previous upgrade. Create it now.
            $conn->exec('CREATE TABLE numeric_data_types_duration (id INT AUTO_INCREMENT NOT NULL, resource_id INT NOT NULL, property_id INT NOT NULL, value BIGINT NOT NULL, INDEX IDX_E1B5FC6089329D25 (resource_id), INDEX IDX_E1B5FC60549213EC (property_id), INDEX property_value (property_id, value), INDEX value (value), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB;');
            $conn->exec('ALTER TABLE numeric_data_types_duration ADD CONSTRAINT FK_E1B5FC6089329D25 FOREIGN KEY (resource_id) REFERENCES resource (id) ON DELETE CASCADE;');
            $conn->exec('ALTER TABLE numeric_data_types_duration ADD CONSTRAINT FK_E1B5FC60549213EC FOREIGN KEY (property_id) REFERENCES property (id) ON DELETE CASCADE;');
        }
        if (Comparator::lessThan($oldVersion, '1.14.0')) {
            // Changing from BIGINT to NUMERIC(32,16) should be safe because all
            // existing values should fit within the specified precision and
            // scale. This is because, prior to this update, the
            // "numeric:integer" data type enforced a compatible minimum and
            // maximum.
            $conn->exec('ALTER TABLE numeric_data_types_integer CHANGE value value NUMERIC(32, 16) NOT NULL;');
        }
    }

    public function attachListeners(SharedEventManagerInterface $sharedEventManager)
    {
        $eventIds = [
            'Omeka\Api\Adapter\ItemAdapter',
            'Omeka\Api\Adapter\ItemSetAdapter',
            'Omeka\Api\Adapter\MediaAdapter',
        ];
        foreach ($eventIds as $eventId) {
            $sharedEventManager->attach(
                $eventId,
                'api.search.query',
                [$this, 'buildQueries']
            );
            $sharedEventManager->attach(
                $eventId,
                'api.search.query',
                [$this, 'sortQueries']
            );
            $sharedEventManager->attach(
                $eventId,
                'api.hydrate.post',
                [$this, 'saveNumericData']
            );
        }

        $eventIds = [
            'Omeka\Controller\Admin\Item',
            'Omeka\Controller\Site\Item',
        ];
        foreach ($eventIds as $eventId) {
            $sharedEventManager->attach(
                $eventId,
                'view.sort-selector',
                function (Event $event) {
                    $sortings = $this->getSortings('Omeka\Entity\Item');
                    $sortConfig = $event->getParam('sortConfig') ?: [];
                    $sortConfig = array_merge($sortConfig, $sortings);
                    $event->setParam('sortConfig', $sortConfig);
                }
            );
        }
        $sharedEventManager->attach(
            'Omeka\Controller\Admin\ItemSet',
            'view.sort-selector',
            function (Event $event) {
                $sortings = $this->getSortings('Omeka\Entity\ItemSet');
                $sortConfig = $event->getParam('sortConfig') ?: [];
                $sortConfig = array_merge($sortConfig, $sortings);
                $event->setParam('sortConfig', $sortConfig);
            }
        );
        $sharedEventManager->attach(
            'Omeka\Controller\Admin\Media',
            'view.sort-selector',
            function (Event $event) {
                $sortings = $this->getSortings('Omeka\Entity\Media');
                $sortConfig = $event->getParam('sortConfig') ?: [];
                $sortConfig = array_merge($sortConfig, $sortings);
                $event->setParam('sortConfig', $sortConfig);
            }
        );

        $eventIds = [
            'Omeka\Controller\Admin\Item',
            'Omeka\Controller\Admin\ItemSet',
            'Omeka\Controller\Admin\Media',
            'Omeka\Controller\Site\Item',
        ];
        foreach ($eventIds as $eventId) {
            $sharedEventManager->attach(
                $eventId,
                'view.advanced_search',
                function (Event $event) {
                    $partials = $event->getParam('partials');
                    $partials[] = 'common/numeric-data-types-advanced-search';
                    $event->setParam('partials', $partials);
                }
            );
        }

        // Add JS to FacetedBrowse category form.
        $sharedEventManager->attach(
            'FacetedBrowse\Controller\SiteAdmin\Category',
            'view.faceted_browse.category_form',
            function (Event $event) {
                $view = $event->getTarget();
                $view->headScript()->appendFile($view->assetUrl('js/faceted-browse/category-form.js', 'NumericDataTypes'));
            }
        );
    }

    /**
     * Save numeric data to the corresponding number tables.
     *
     * This clears all existing numbers and (re)saves them during create and
     * update operations for a resource (item, item set, media). We do this as
     * an easy way to ensure that the numbers in the number tables are in sync
     * with the numbers in the value table.
     *
     * This will work for Item, ItemSet, and Media resources.
     *
     * @param Event $event
     */
    public function saveNumericData(Event $event)
    {
        $entity = $event->getParam('entity');
        if (!$entity instanceof \Omeka\Entity\Resource) {
            return; // This is not a resource entity.
        }

        $allValues = $entity->getValues();
        foreach ($this->getNumericDataTypes() as $dataTypeName => $dataType) {
            $criteria = Criteria::create()
                ->where(Criteria::expr()
                ->eq('type', $dataTypeName));
            $matchingValues = $allValues->matching($criteria);
            if (!$matchingValues) {
                // This resource has no number values of this type.
                continue;
            }

            $em = $this->getServiceLocator()->get('Omeka\EntityManager');
            $existingNumbers = [];

            if ($entity->getId()) {
                $dql = sprintf(
                    'SELECT n FROM %s n WHERE n.resource = :resource',
                    $dataType->getEntityClass()
                );
                $query = $em->createQuery($dql);
                $query->setParameter('resource', $entity);
                $existingNumbers = $query->getResult();
            }
            foreach ($matchingValues as $value) {
                // Avoid ID churn by reusing number rows.
                $number = current($existingNumbers);
                if ($number === false) {
                    // No more number rows to reuse. Create a new one.
                    $entityClass = $dataType->getEntityClass();
                    $number = new $entityClass;
                    $em->persist($number);
                } else {
                    // Null out numbers as we reuse them. Note that existing
                    // numbers are already managed and will update during flush.
                    $existingNumbers[key($existingNumbers)] = null;
                    next($existingNumbers);
                }
                $number->setResource($entity);
                $number->setProperty($value->getProperty());
                $dataType->setEntityValues($number, $value);
            }
            // Remove any numbers that weren't reused.
            foreach ($existingNumbers as $existingNumber) {
                if (null !== $existingNumber) {
                    $em->remove($existingNumber);
                }
            }
        }
    }

    /**
     * Build numerical queries.
     *
     * @param Event $event
     */
    public function buildQueries(Event $event)
    {
        $query = $event->getParam('request')->getContent();
        if (!isset($query['numeric'])) {
            return;
        }
        $adapter = $event->getTarget();
        $qb = $event->getParam('queryBuilder');
        foreach ($this->getNumericDataTypes() as $dataType) {
            $dataType->buildQuery($adapter, $qb, $query);
        }
    }

    /**
     * Sort numerical queries.
     *
     * sort_by=numeric:<type>:<propertyId>
     *
     * @param Event $event
     */
    public function sortQueries(Event $event)
    {
        $adapter = $event->getTarget();
        $qb = $event->getParam('queryBuilder');
        $query = $event->getParam('request')->getContent();

        if (!isset($query['sort_by']) || !is_string($query['sort_by'])) {
            return;
        }
        $sortBy = explode(':', $query['sort_by']);
        if (3 !== count($sortBy)) {
            return;
        }
        [$namespace, $type, $propertyId] = $sortBy;
        if ('numeric' !== $namespace || !is_string($type) || !is_numeric($propertyId)) {
            return;
        }
        foreach ($this->getNumericDataTypes() as $dataType) {
            $dataType->sortQuery($adapter, $qb, $query, $type, $propertyId);
        }
    }

    /**
     * Get numeric sort options for sort by form.
     *
     * @param string $instanceOf Omeka\Entity\Item, Omeka\Entity\ItemSet, Omeka\Entity\Media
     */
    public function getSortings($instanceOf)
    {
        $services = $this->getServiceLocator();
        $entityManager = $services->get('Omeka\EntityManager');
        $translator = $services->get('MvcTranslator');

        $numericDataTypes = $this->getNumericDataTypes();
        $sortings = [];
        foreach ($numericDataTypes as $numericDataType) {
            // Get only those properties that have corresponding numeric data
            // type values that are assigned to resources of the passed instance.
            $dql = sprintf('SELECT DISTINCT property.id, property.label
                FROM %s ndt
                JOIN ndt.property property
                JOIN ndt.resource resource
                WHERE resource INSTANCE OF %s',
                $numericDataType->getEntityClass(),
                $instanceOf
            );
            $query = $entityManager->createQuery($dql);
            $properties = $query->getResult();
            foreach ($properties as $property) {
                $sortingKey = sprintf('%s:%s', $numericDataType->getName(), $property['id']);
                $sortingValue = sprintf('%s (%s)', $translator->translate($property['label']), $numericDataType->getName());
                $sortings[$sortingKey] = $sortingValue;
            }
        }
        asort($sortings);
        return $sortings;
    }

    /**
     * Get all data types added by this module.
     *
     * @return array
     */
    public function getNumericDataTypes()
    {
        $dataTypes = $this->getServiceLocator()->get('Omeka\DataTypeManager');
        $numericDataTypes = [];
        foreach ($dataTypes->getRegisteredNames() as $dataType) {
            if (0 === strpos($dataType, 'numeric:')) {
                $numericDataTypes[$dataType] = $dataTypes->get($dataType);
            }
        }
        return $numericDataTypes;
    }
}
