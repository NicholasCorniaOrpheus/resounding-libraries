document.addEventListener("DOMContentLoaded", function () {
    console.log("ShowMore: DOM loaded, starting processing");

    // Read configuration from global object (set by Module.php) or use embedded placeholders
    var showMoreMode, showMoreLimit, excludedProperties, expandAllEnabled;

    if (typeof window.ShowMoreConfig !== 'undefined') {
        // New method: read from global config
        console.log("ShowMore: Configuration loaded:", window.ShowMoreConfig);
        showMoreMode = window.ShowMoreConfig.mode;
        showMoreLimit = window.ShowMoreConfig.limit;
        excludedProperties = window.ShowMoreConfig.excludedProperties;
        expandAllEnabled = window.ShowMoreConfig.expandAllEnabled;
    } else {
        // Old method: embedded placeholders (fallback)
        showMoreMode = "__SHOW_MORE_MODE__";
        showMoreLimit = __SHOW_MORE_LIMIT__;
        excludedProperties = __EXCLUDED_PROPERTIES__;
        expandAllEnabled = __EXPAND_ALL_ENABLED__;
    }

    // Global variables for expand all functionality
    let expandAllButton = null;
    let expandAllContainer = null;
    let showMoreContainers = [];

    // Function to count words
    function countWords(text) {
        return text.trim().split(/\s+/).filter(function (word) {
            return word.length > 0;
        }).length;
    }

    function truncateHTML(html, maxLength, mode) {
        var tempDiv = document.createElement('div');
        tempDiv.innerHTML = html;
        var fullText = tempDiv.textContent || tempDiv.innerText;

        console.log("=== truncateHTML START ===");
        console.log("Input html:", html.substring(0, 100) + "...");
        console.log("maxLength:", maxLength, "mode:", mode);

        // If content is already short enough, return as-is
        var actualLength = mode === 'words' ? countWords(fullText) : Array.from(fullText).length;
        console.log("actualLength:", actualLength);

        if (actualLength <= maxLength) {
            console.log("Returning original - no truncation needed");
            return html;
        }

        var targetLength;
        if (mode === 'words') {
            var words = fullText.trim().split(/\s+/);
            targetLength = words.slice(0, maxLength).join(' ').length;
        } else {
            targetLength = maxLength;
        }
        console.log("targetLength:", targetLength);

        // Walk through the DOM and build truncated HTML
        var result = '';
        var currentLength = 0;

        function walkNode(node) {
            if (currentLength >= targetLength) {
                return false;
            }

            if (node.nodeType === 3) { // TEXT_NODE
                var text = node.textContent;
                var textArray = Array.from(text);
                var remainingLength = targetLength - currentLength;

                if (textArray.length <= remainingLength) {
                    currentLength += textArray.length;
                    result += text;
                } else {
                    var truncated = textArray.slice(0, remainingLength);
                    if (mode === 'words') {
                        var truncatedStr = truncated.join("");
                        var lastSpace = truncatedStr.lastIndexOf(' ');
                        if (lastSpace > remainingLength * 0.8) {
                            truncated = truncated.slice(0, lastSpace);
                        }
                    }
                    result += truncated.join("");
                    currentLength = targetLength;
                    return false;
                }
            } else if (node.nodeType === 1) {  // ELEMENT_NODE
                var tagName = node.tagName.toLowerCase();
                var attributes = '';

                // Copy attributes
                for (var i = 0; i < node.attributes.length; i++) {
                    var attr = node.attributes[i];
                    attributes += ' ' + attr.name + '="' + attr.value + '"';
                }

                result += '<' + tagName + attributes + '>';

                // Process children
                for (var i = 0; i < node.childNodes.length; i++) {
                    if (!walkNode(node.childNodes[i])) {
                        break;
                    }
                }

                result += '</' + tagName + '>';
            }
            return true;
        }

        // Process all child nodes
        for (var i = 0; i < tempDiv.childNodes.length; i++) {
            if (!walkNode(tempDiv.childNodes[i])) {
                break;
            }
        }

        console.log("=== truncateHTML END ===");
        return result;
    }

    // Function to create expand all/collapse all button
    function createExpandAllButton() {
        expandAllContainer = document.createElement('div');
        expandAllContainer.className = 'show-more-expand-all-container hidden';
        expandAllContainer.style.position = 'static';
        expandAllContainer.style.background = 'transparent';
        expandAllContainer.style.border = 'none';
        expandAllContainer.style.boxShadow = 'none';
        expandAllContainer.style.marginBottom = '20px';
        expandAllContainer.style.padding = '8px 0';

        expandAllButton = document.createElement('button');
        expandAllButton.type = 'button';
        expandAllButton.className = 'show-more-expand-all-btn';
        expandAllButton.textContent = 'Expand all';

        expandAllButton.addEventListener('click', function () {
            const isExpandingAll = expandAllButton.textContent === 'Expand all';

            showMoreContainers.forEach(function (container) {
                const button = container.querySelector('.show-more-btn');
                const contentSpan = container.querySelector('.content-text');
                const isCurrentlyExpanded = container.classList.contains('expanded');

                if (isExpandingAll && !isCurrentlyExpanded) {
                    contentSpan.innerHTML = container.getAttribute('data-full-html');
                    button.textContent = button.getAttribute('data-hide-text');
                    container.classList.add('expanded');
                } else if (!isExpandingAll && isCurrentlyExpanded) {
                    contentSpan.innerHTML = container.getAttribute('data-truncated-html');
                    button.textContent = button.getAttribute('data-show-text');
                    container.classList.remove('expanded');
                }
            });

            expandAllButton.textContent = isExpandingAll ? 'Collapse all' : 'Expand all';
        });

        expandAllContainer.appendChild(expandAllButton);

        // Try multiple insertion strategies
        let inserted = false;
        const itemHeading = document.querySelector('h3');
        const metadataSection = document.querySelector('dl');

        if (itemHeading && metadataSection && itemHeading.parentNode === metadataSection.parentNode) {
            try {
                itemHeading.parentNode.insertBefore(expandAllContainer, metadataSection);
                inserted = true;
                console.log("ShowMore: Expand all button inserted after heading");
            } catch (e) {
                console.log("ShowMore: Insertion method 1 failed:", e);
            }
        }

        if (!inserted && itemHeading) {
            try {
                if (itemHeading.nextSibling) {
                    itemHeading.parentNode.insertBefore(expandAllContainer, itemHeading.nextSibling);
                } else {
                    itemHeading.parentNode.appendChild(expandAllContainer);
                }
                inserted = true;
                console.log("ShowMore: Expand all button inserted via method 2");
            } catch (e) {
                console.log("ShowMore: Insertion method 2 failed:", e);
            }
        }

        if (!inserted && metadataSection) {
            try {
                metadataSection.parentNode.insertBefore(expandAllContainer, metadataSection);
                inserted = true;
                console.log("ShowMore: Expand all button inserted via method 3");
            } catch (e) {
                console.log("ShowMore: Insertion method 3 failed:", e);
            }
        }

        if (!inserted) {
            try {
                document.body.appendChild(expandAllContainer);
                inserted = true;
                console.log("ShowMore: Expand all button inserted as fallback");
            } catch (e) {
                console.error("ShowMore: All insertion methods failed:", e);
            }
        }
    }

    // Check if we should process this page
    var isItemShowPage = document.body.classList.contains("item") &&
        document.body.classList.contains("show");

    console.log("ShowMore: Is item show page?", isItemShowPage);
    console.log("ShowMore: Body classes:", document.body.className);

    if (!isItemShowPage) {
        console.log("ShowMore: Not an item show page, exiting");
        return;
    }

    console.log("ShowMore: Processing item show page");
    console.log("ShowMore: Mode:", showMoreMode, "Limit:", showMoreLimit);

    // Exit if limit is 0 (disabled)
    if (showMoreLimit === 0) {
        console.log("ShowMore: Limit is 0, functionality disabled");
        return;
    }

    // Create expand all button if enabled
    if (expandAllEnabled) {
        createExpandAllButton();
    }

    function isPropertyExcluded(propertyLabel) {
        if (!excludedProperties || excludedProperties.length === 0) {
            return false;
        }

        return excludedProperties.some(function (term) {
            var localPart = term.split(':')[1];
            var spacedLabel = localPart.replace(/([A-Z])/g, ' $1').toLowerCase().trim();
            return propertyLabel.toLowerCase() === spacedLabel ||
                propertyLabel.toLowerCase().includes(localPart.toLowerCase());
        });
    }

    // Process each property
    var dtElements = document.querySelectorAll("dt");
    console.log("ShowMore: Found", dtElements.length, "dt elements");

    dtElements.forEach(function (dt) {
        var propertyLabel = dt.textContent.trim();

        if (isPropertyExcluded(propertyLabel)) {
            console.log("ShowMore: Skipping excluded property:", propertyLabel);
            return;
        }

        console.log("ShowMore: Processing property:", propertyLabel);
        var nextElement = dt.nextElementSibling;

        while (nextElement && nextElement.tagName === "DD") {
            var valueContent = nextElement.querySelector(".value-content");

            if (valueContent) {
                var originalText = valueContent.textContent.trim();
                var originalHTML = valueContent.innerHTML;
                var needsTruncation = false;

                if (showMoreMode === "words") {
                    var wordCount = countWords(originalText);
                    needsTruncation = wordCount > showMoreLimit;
                    console.log("ShowMore:", propertyLabel, "- Word count:", wordCount, "Needs truncation:", needsTruncation);
                } else {
                    var charCount = Array.from(originalText).length;
                    needsTruncation = charCount > showMoreLimit;
                    console.log("ShowMore:", propertyLabel, "- Character count:", charCount, "Needs truncation:", needsTruncation);
                }

                if (needsTruncation) {
                    console.log("ShowMore: Applying truncation to", propertyLabel);

                    var truncatedHTML = truncateHTML(originalHTML, showMoreLimit, showMoreMode);
                    var uniqueId = "show-more-" + Math.random().toString(36).substr(2, 9);
                    var container = document.createElement("div");
                    container.className = "show-more-content show-more-metadata";
                    container.id = uniqueId;

                    var contentSpan = document.createElement("span");
                    contentSpan.className = "content-text";
                    contentSpan.innerHTML = truncatedHTML;

                    var button = document.createElement("button");
                    button.type = "button";
                    button.className = "show-more-btn";
                    button.setAttribute("data-show-text", "Show more");
                    button.setAttribute("data-hide-text", "Show less");
                    button.textContent = "Show more";

                    container.setAttribute("data-full-html", originalHTML);
                    container.setAttribute("data-truncated-html", truncatedHTML);

                    showMoreContainers.push(container);

                    button.addEventListener("click", (function (btnContainer, btnContentSpan, btnButton) {
                        return function () {
                            var isExpanded = btnContainer.classList.contains("expanded");

                            if (isExpanded) {
                                btnContentSpan.innerHTML = btnContainer.getAttribute("data-truncated-html");
                                btnButton.textContent = btnButton.getAttribute("data-show-text");
                                btnContainer.classList.remove("expanded");
                            } else {
                                btnContentSpan.innerHTML = btnContainer.getAttribute("data-full-html");
                                btnButton.textContent = btnButton.getAttribute("data-hide-text");
                                btnContainer.classList.add("expanded");
                            }
                        };
                    })(container, contentSpan, button));

                    container.appendChild(contentSpan);
                    container.appendChild(document.createTextNode(" "));
                    container.appendChild(button);

                    valueContent.innerHTML = "";
                    valueContent.appendChild(container);

                    console.log("ShowMore: Successfully applied to", propertyLabel);
                }
            }

            nextElement = nextElement.nextElementSibling;
        }
    });

    // Show expand all button if we have containers
    if (expandAllEnabled && showMoreContainers.length > 0) {
        expandAllContainer.classList.remove('hidden');
        console.log("ShowMore: Expand all button shown with", showMoreContainers.length, "containers");
    }

    console.log("ShowMore: Processing complete");
});