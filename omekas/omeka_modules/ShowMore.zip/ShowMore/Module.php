<?php
namespace ShowMore;

use Omeka\Module\AbstractModule;
use Laminas\EventManager\Event;
use Laminas\EventManager\SharedEventManagerInterface;
use Laminas\Mvc\MvcEvent;

class Module extends AbstractModule
{
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function onBootstrap(MvcEvent $event)
    {
        parent::onBootstrap($event);

        $acl = $this->getServiceLocator()->get('Omeka\Acl');
        $acl->allow(
            null,
            ['ShowMore\Controller\SiteAdmin\Index']
        );
    }

    public function attachListeners(SharedEventManagerInterface $sharedEventManager)
    {
        // Attach to item show page view events
        $sharedEventManager->attach(
            'Omeka\Controller\Site\Item',
            'view.show.after',
            [$this, 'injectShowMoreAssets']
        );

        // Also attach to head event for earlier injection
        $sharedEventManager->attach(
            'Omeka\Controller\Site\Item',
            'view.show.before',
            [$this, 'injectShowMoreAssets']
        );
    }

    /**
     * Inject Show More assets on item show pages
     */
    public function injectShowMoreAssets(Event $event)
    {
        $view = $event->getTarget();

        // Prevent double-injection
        static $injected = false;
        if ($injected) {
            return;
        }

        $this->injectAssets($view);
        $injected = true;
    }

    /**
     * Inject CSS and JavaScript assets for Show More functionality
     */
    protected function injectAssets($view)
    {
        try {
            // Check if site has Show More enabled
            $showMoreMode = $view->siteSetting('show_more_mode');
            $showMoreLimit = (int) $view->siteSetting('show_more_limit', 0);
            $expandAllEnabled = (bool) $view->siteSetting('show_more_expand_all_enabled', true);

            // Get excluded property IDs and convert to terms
            $excludedPropertyIds = $view->siteSetting('show_more_excluded_properties', []);
            if (!is_array($excludedPropertyIds)) {
                $excludedPropertyIds = [];
            }

            $excludedPropertyTerms = $this->getPropertyTerms($view, $excludedPropertyIds);

            // Log for debugging
            error_log('ShowMore: Injecting assets - Mode: ' . $showMoreMode . ', Limit: ' . $showMoreLimit);

            // Only inject assets if show more is configured
            if (!$showMoreMode || $showMoreLimit === 0) {
                error_log('ShowMore: Not injecting - mode or limit not set');
                return;
            }

            // Use proper asset URLs instead of inline injection
            $assetUrl = $view->plugin('assetUrl');

            // Add CSS file
            $cssUrl = $assetUrl('css/show-more.css', 'ShowMore');
            $view->headLink()->appendStylesheet($cssUrl);
            error_log('ShowMore: Added CSS: ' . $cssUrl);

            // Create configuration as a separate script block
            $config = [
                'mode' => $showMoreMode,
                'limit' => $showMoreLimit,
                'excludedProperties' => $excludedPropertyTerms,
                'expandAllEnabled' => $expandAllEnabled
            ];

            // Inject configuration before the main script
            $configScript = sprintf(
                'window.ShowMoreConfig = %s; console.log("ShowMore config loaded:", window.ShowMoreConfig);',
                json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)
            );

            $view->headScript()->appendScript($configScript);
            error_log('ShowMore: Added config script');

            // Add main JavaScript file
            $jsUrl = $assetUrl('js/show-more.js', 'ShowMore');
            $view->headScript()->appendFile($jsUrl);
            error_log('ShowMore: Added JS: ' . $jsUrl);

        } catch (\Exception $e) {
            error_log('ShowMore: Error injecting assets: ' . $e->getMessage());
            error_log('ShowMore: Stack trace: ' . $e->getTraceAsString());
        }
    }

    /**
     * Get property terms from property IDs
     */
    protected function getPropertyTerms($view, $propertyIds)
    {
        if (empty($propertyIds)) {
            return [];
        }

        $terms = [];
        try {
            $properties = $view->api()->search('properties', ['id' => $propertyIds])->getContent();
            foreach ($properties as $property) {
                $terms[] = $property->term();
            }
            error_log('ShowMore: Loaded ' . count($terms) . ' excluded property terms');
        } catch (\Exception $e) {
            error_log('ShowMore: Error getting property terms: ' . $e->getMessage());
        }

        return $terms;
    }
}
