<?php declare(strict_types=1);

namespace Mapper;

if (!class_exists(\Common\TraitModule::class, false)) {
    require_once dirname(__DIR__) . '/Common/TraitModule.php';
}

use Common\TraitModule;
use Omeka\Module\AbstractModule;

/**
 * Mapper.
 *
 * A tool to convert values from a source to values in Omeka resources.
 *
 * @copyright Daniel Berthereau, 2013-2026
 * @license http://www.cecill.info/licences/Licence_CeCILL_V2.1-en.txt
 */
class Module extends AbstractModule
{
    use TraitModule;

    const NAMESPACE = __NAMESPACE__;

    protected function preInstall(): void
    {
        $services = $this->getServiceLocator();
        $translate = $services->get('ControllerPluginManager')->get('translate');

        if (!method_exists($this, 'checkModuleActiveVersion') || !$this->checkModuleActiveVersion('Common', '3.4.75')) {
            $message = new \Omeka\Stdlib\Message(
                $translate('The module %1$s should be upgraded to version %2$s or later.'), // @translate
                'Common', '3.4.75'
            );
            throw new \Omeka\Module\Exception\ModuleCannotInstallException((string) $message);
        }
    }

    protected function postInstall(): void
    {
        $this->migrateFromBulkImport();
        $this->postInstallAuto();
    }

    /**
     * Migrate mappings from BulkImport module if it exists.
     */
    protected function migrateFromBulkImport(): void
    {
        $services = $this->getServiceLocator();
        $connection = $services->get('Omeka\Connection');
        $logger = $services->get('Omeka\Logger');

        // Check if bulk_mapping table exists (BulkImport installed).
        try {
            $tableExists = $connection->executeQuery(
                'SHOW TABLES LIKE "bulk_mapping"'
            )->fetchOne();
        } catch (\Exception $e) {
            return;
        }

        if (!$tableExists) {
            return;
        }

        try {
            // Migrate existing mappings to new 'mapper' table
            $result = $connection->executeStatement(<<<'SQL'
                INSERT INTO mapper (owner_id, label, mapping, created, modified)
                SELECT owner_id, label, mapping, created, modified
                FROM bulk_mapping
                WHERE label NOT IN (SELECT label FROM mapper)
                SQL);

            if ($result > 0) {
                $logger->info(
                    'Mapper: Migrated {count} mappings from BulkImport.', // @translate
                    ['count' => $result]
                );
            }
        } catch (\Exception $e) {
            $logger->err(
                'Mapper: Error during migration from BulkImport: {error}', // @translate
                ['error' => $e->getMessage()]
            );
        }
    }
}
