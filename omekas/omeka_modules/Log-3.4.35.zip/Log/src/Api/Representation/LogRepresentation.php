<?php declare(strict_types=1);

namespace Log\Api\Representation;

use Common\Stdlib\PsrMessage;
use DateTime;
use Log\Stdlib\JobState;
use Omeka\Api\Representation\AbstractEntityRepresentation;
use Omeka\Api\Representation\JobRepresentation;
use Omeka\Api\Representation\UserRepresentation;

class LogRepresentation extends AbstractEntityRepresentation
{
    const SEVERITIES = [
        \Laminas\Log\Logger::EMERG => 'emergency', // @translate
        \Laminas\Log\Logger::ALERT => 'alert', // @translate
        \Laminas\Log\Logger::CRIT => 'critical', // @translate
        \Laminas\Log\Logger::ERR => 'error', // @translate
        \Laminas\Log\Logger::WARN => 'warning', // @translate
        \Laminas\Log\Logger::NOTICE => 'notice', // @translate
        \Laminas\Log\Logger::INFO => 'info', // @translate
        \Laminas\Log\Logger::DEBUG => 'debug', // @translate
    ];

    /**
     * Map of resource names/context keys to admin controller names.
     */
    const RESOURCES_TO_CONTROLLERS = [
        'asset' => 'asset',
        'assets' => 'asset',
        'item' => 'item',
        'items' => 'item',
        'item set' => 'item-set',
        'itemset' => 'item-set',
        'itemsets' => 'item-set',
        'job' => 'job',
        'jobs' => 'job',
        'media' => 'media',
        'resourcetemplate' => 'resource-template',
        'template' => 'resource-template',
        'user' => 'user',
        'users' => 'user',
        'annotation' => 'annotation',
        'annotations' => 'annotation',
        'table' => 'table',
        'tables' => 'table',
        // For context.
        'itemid' => 'item',
        'itemids' => 'item',
        'itemsetid' => 'item-set',
        'itemsetids' => 'item-set',
        'jobid' => 'job',
        'jobids' => 'job',
        'mediaid' => 'media',
        'mediaids' => 'media',
        'oaiid' => 'oai-pmh',
        'oaiids' => 'oai-pmh',
        'ownerid' => 'user',
        'ownerids' => 'user',
        'userid' => 'user',
        'userids' => 'user',
        'resourcetemplateid' => 'resource-template',
        'resourcetemplateids' => 'resource-template',
        'templateid' => 'resource-template',
        'templateids' => 'resource-template',
        'annotationid' => 'annotation',
        'annotationids' => 'annotation',
        'tableid' => 'table',
        'tableids' => 'table',
        'tableslug' => 'table',
        'tableslugs' => 'table',
    ];

    /**
     * @var \Log\Entity\Log
     */
    protected $resource;

    public function getControllerName(): string
    {
        return 'log';
    }

    public function getJsonLdType(): string
    {
        return 'o:Log';
    }

    public function getJsonLd()
    {
        $owner = $this->owner();
        $job = $this->job();

        /**
         * @todo Find the schema for log severity.
         * In fact, no standard schema exists.
         *
         * @see https://tools.ietf.org/html/rfc3164#page-9 (first)
         * @see https://datatracker.ietf.org/doc/html/rfc5424#page-11 (last)
         *
         * Omeka 4.2 uses php 7.4, so no short nullsafe operator "?->".
         */

        return [
            'o:reference' => $this->reference(),
            'o:severity' => $this->severity(),
            'o:message' => $this->message(),
            'o:context' => $this->context(),
            'o:created' => [
                '@value' => $this->getDateTime($this->created())->jsonSerialize(),
                '@type' => 'http://www.w3.org/2001/XMLSchema#dateTime',
            ],
            'o:owner' => $owner ? $owner->getReference()->jsonSerialize() : null,
            'o:job' => $job ? $job->getReference()->jsonSerialize() : null,
        ];
    }

    public function reference(): string
    {
        return $this->resource->getReference();
    }

    public function severity(): int
    {
        return $this->resource->getSeverity();
    }

    public function severityLabel(): string
    {
        $severity = $this->severity();
        return self::SEVERITIES[$severity] ?? $severity;
    }

    public function message(): PsrMessage
    {
        $translator = $this->getServiceLocator()->get('MvcTranslator');
        $message = $this->resource->getMessage();
        $context = $this->resource->getContext() ?: [];
        $psrMessage = new PsrMessage($message, $context);
        return $psrMessage
            ->setTranslator($translator);
    }

    /**
     * Return translatable message with context (resource links).
     */
    public function text(): PsrMessage
    {
        /**
         * @var \Omeka\Api\Manager $api
         * @var \Omeka\View\Helper\Url $url
         * @var \Omeka\View\Helper\Hyperlink $hyperlink
         * @var \Omeka\I18n\Translator $translator
         */
        $services = $this->getServiceLocator();
        $url = $this->getViewHelper('url');
        $api = $this->getViewHelper('api');
        $escape = $this->getViewHelper('escapeHtml');
        $hyperlink = $this->getViewHelper('hyperlink');
        $translator = $services->get('MvcTranslator');

        // For speed, use a base url so just append the controller name and the
        // resource id without full url processing.
        // In logs, it is recommended to use the precise context when possible.
        $resourcesToControllers = self::RESOURCES_TO_CONTROLLERS;
        $baseUrl = strtr($url('admin/default', ['controller' => 'replace']), ['/replace' => '']);

        $escapeHtml = true;
        $message = $this->resource->getMessage();
        $context = $this->resource->getContext() ?: [];
        $jobArgs = ($job = $this->resource->getJob()) ? $job->getArgs() : [];
        $matches = [];

        // Messages that are more than 1000 characters are generally an
        // exception with an sql and long parameters, in particular the text
        // used for the full text search.
        $tooMuchLong = strlen($message) > 100000
            || strlen(json_encode($context)) > 100000;
        if ($tooMuchLong) {
            foreach ($context ?? [] as &$v) {
                if (is_string($v) && mb_strlen($v) > 100000) {
                    $v = mb_substr($v, 0, 100000);
                }
            }
            unset($v);
            $message = new PsrMessage(mb_substr($message, 0, 100000) . '…', $context);
            return $message
                ->setTranslator($translator);
        }

        if ($context) {
            $shouldEscapes = [];
            $prevSiteSlug = null;
            foreach ($context as $key => $value) {
                $shouldEscapes[$key] = true;
                $value = trim((string) $value);
                $lowerKey = strtolower((string) $key);
                $cleanKey = preg_replace('~[^a-z]~', '', $lowerKey);
                switch ($cleanKey) {
                    // Single id.
                    case 'itemid':
                    case 'itemsetid':
                    case 'jobid':
                    case 'mediaid':
                    case 'resourcetemplateid':
                    case 'templateid':
                    case 'ownerid':
                    case 'userid':
                    case 'annotationid':
                    case 'tableid':
                    // Multiple ids.
                    case 'itemids':
                    case 'itemsetids':
                    case 'jobids':
                    case 'mediaids':
                    case 'resourcetemplateids':
                    case 'templateids':
                    case 'ownerids':
                    case 'userids':
                    case 'annotationids':
                    case 'tableids':
                        $controller = $resourcesToControllers[$cleanKey]
                            ?? $resourcesToControllers[substr($cleanKey, 0, -1)];
                        $values = array_values(array_filter(explode(' ', preg_replace('~[^0-9]~', ' ', $value))));
                        if ($values) {
                            $link = $hyperlink('__ID__', "$baseUrl/$controller/__ID__");
                            $context[$key] = '';
                            foreach ($values as $val) {
                                $context[$key] .= ', ' . strtr($link, ['__ID__' => $val]);
                            }
                            $context[$key] = trim($context[$key], ', ');
                            $shouldEscapes[$key] = false;
                        }
                        break;

                    case 'assetid':
                    case 'assetids':
                        $values = array_values(array_filter(explode(' ', preg_replace('~[^0-9]~', ' ', $value))));
                        if ($values) {
                            $link = $hyperlink('__ID__', "$baseUrl/asset?id=__ID__");
                            $context[$key] = '';
                            foreach ($values as $val) {
                                $context[$key] .= ', ' . strtr($link, ['__ID__' => $val]);
                            }
                            $context[$key] = trim($context[$key], ', ');
                            $shouldEscapes[$key] = false;
                        }
                        break;

                    case 'id':
                    case 'resourceid':
                    case 'ids':
                    case 'resourceids':
                        $values = array_values(array_filter(explode(' ', preg_replace('~[^0-9]~', ' ', $value))));
                        $resourceType = $context['resource']
                            ?? $context['resource_name']
                            ?? $context['resource_type']
                            ?? $context['entity_name']
                            ?? $jobArgs['resource_name']
                            ?? $jobArgs['resource_type']
                            ?? $jobArgs['entity_name']
                            ?? null;
                        if ($values && $resourceType) {
                            $resourceType = preg_replace('~[^a-z]~', '', strtolower($resourceType));
                            if (isset($resourcesToControllers[$resourceType])) {
                                $controller = $resourcesToControllers[$resourceType];
                                $link = $controller === 'asset'
                                    ? $hyperlink('__ID__', "$baseUrl/asset?id=__ID__}}")
                                    : $hyperlink('__ID__', "$baseUrl/$controller/__ID__");
                                $context[$key] = '';
                                foreach ($values as $val) {
                                    $context[$key] .= ', ' . strtr($link, ['__ID__' => $val]);
                                }
                                $context[$key] = trim($context[$key], ', ');
                                $shouldEscapes[$key] = false;
                                if (isset($context['resource'])) {
                                    $context['resource'] = $translator->translate($context['resource']);
                                }
                                if (isset($context['resource_name'])) {
                                    $context['resource_name'] = $translator->translate($context['resource_name']);
                                }
                                if (isset($context['resource_type'])) {
                                    $context['resource_type'] = $translator->translate($context['resource_type']);
                                }
                            }
                        } elseif (count($values) === 1 && in_array($cleanKey, ['resourceid', 'resourceids'])) {
                            try {
                                /** @var \Omeka\Api\Representation\AbstractResourceEntityRepresentation $resource */
                                $controller = $api->read('resources', $value)->getContent()->getControllerName();
                                $context[$key] = $hyperlink($value, "$baseUrl/$controller/$value");
                                $shouldEscapes[$key] = false;
                            } catch (\Exception $e) {
                            }
                        }
                        // TODO Else link with "?id[]=xxx".
                        break;

                    case 'siteslug':
                        $context[$key] = $hyperlink($value, "$baseUrl/site/s/$value");
                        $shouldEscapes[$key] = false;
                        $prevSiteSlug = $value;
                        break;
                    case 'pageslug':
                        if ($prevSiteSlug) {
                            $context[$key] = $hyperlink($value, "$baseUrl/site/s/$prevSiteSlug/page/$value");
                            $shouldEscapes[$key] = false;
                        } elseif (isset($context['site_slug'])) {
                            $context[$key] = $hyperlink($value, "$baseUrl/site/s/{$context['site_slug']}/page/$value");
                            $shouldEscapes[$key] = false;
                        }
                        break;

                    case 'oaiurl':
                    case 'urloai':
                    case 'oaiendpoint':
                        $context[$key] = $hyperlink(basename($value), $value . '?verb=Identify', ['target' => '_blank']);
                        $shouldEscapes[$key] = false;
                        break;

                    case 'url':
                    // Start or end with "url".
                    case 'siteurl':
                    case 'pageurl':
                    case strpos($lowerKey, 'url') === 0:
                    case mb_substr($lowerKey, -3) === 'url':
                        $context[$key] = $hyperlink(basename($value), $value, ['target' => '_blank']);
                        $shouldEscapes[$key] = false;
                        break;
                    case 'href':
                    case 'link':
                        $shouldEscapes[$key] = false;
                        break;

                    case 'oaiid':
                        $oaiEndpoint = $context['oai_endpoint']
                            ?? $context['oai_url']
                            ?? $context['url_oai']
                            ?? $jobArgs['oai_endpoint']
                            ?? $jobArgs['endpoint']
                            ?? null;
                        if ($oaiEndpoint) {
                            $context[$key] = $hyperlink($value, "$oaiEndpoint?verb=GetRecord&metadataPrefix=oai_dc&identifier=" . rawurlencode($value), ['target' => '_blank']);
                            $shouldEscapes[$key] = false;
                        }
                        break;

                    case 'tableslug':
                        $context[$key] = $hyperlink($value, "$baseUrl/table/$value/show");
                        $shouldEscapes[$key] = false;
                        $prevSiteSlug = $value;
                        break;
                    case 'tableslugs':
                        $values = array_values(array_filter(explode(' ', preg_replace('~,~', ' ', $value))));
                        if ($values) {
                            $link = $hyperlink('__ID__', "$baseUrl/table/__ID__/show");
                            $context[$key] = '';
                            foreach ($values as $val) {
                                $context[$key] .= ', ' . strtr($link, ['__ID__' => $val]);
                            }
                            $context[$key] = trim($context[$key], ', ');
                            $shouldEscapes[$key] = false;
                        }
                        break;

                    case 'thesaurusid':
                        $context[$key] = $hyperlink($value, "$baseUrl/thesaurus/$value/structure");
                        $shouldEscapes[$key] = false;
                        break;

                    case 'json':
                        $value = json_decode($value, true);
                        $context[$key] = $value ? json_encode($value, 448) : $value;
                        break;

                    case 'customvocab' && preg_match('~^customvocab:(?<id>\d+)$~', $value, $matches):
                    case 'datatype' && preg_match('~^customvocab:(?<id>\d+)$~', $value, $matches):
                        // There is no page "show" for custom vocab for now.
                        $context[$key] = $hyperlink($value, "$baseUrl/custom-vocab?id=" . $matches['id']);
                        $shouldEscapes[$key] = false;
                        break;

                    default:
                        // In many places, an array is stored as json, that is
                        // the default transformation, so display it cleanerly.
                        if ($value
                            && mb_substr($value, 0, 1) === '{'
                            && mb_substr($value, -1) === '}'
                            && is_array($v = json_decode($value, true))
                        ) {
                            $context[$key] = json_encode($v, 448);
                        }
                        break;
                }
            }
            $countKeys = count($context);
            $countShouldEscape = count(array_filter($shouldEscapes));
            $countShouldNotEscape = $countKeys - $countShouldEscape;
            if ($countKeys === $countShouldEscape) {
                $escapeHtml = true;
            } elseif ($countKeys === $countShouldNotEscape) {
                $escapeHtml = false;
            } else {
                // Manual escaping.
                $escapeHtml = false;
                foreach ($context as $key => $value) {
                    if ($shouldEscapes[$key]) {
                        if (is_scalar($value)) {
                            $context[$key] = $escape($value);
                        } elseif (is_array($value)) {
                            $v = $value;
                            array_walk_recursive($v, $escape);
                            $context[$key] = $v;
                        }
                        // Skip null or other non-array/non-scalar values.
                    }
                }
            }
        } else {
            // Manage simple logs.
            // Add resource links for logs with strings like "item #xxx".
            // TODO Manage "resource" (or a route redirect).
            if (mb_strpos($message, '#')) {
                $count = 0;
                $message = preg_replace_callback('~(?<resource>item set|item|job|media|owner|user|annotation) #(?<id>\d+)~i', function ($matches) use ($hyperlink, $baseUrl, $resourcesToControllers) {
                $controller = $resourcesToControllers[strtolower($matches['resource'])];
                return $matches['resource'] . ' #' . ($controller === 'asset'
                    ? $hyperlink($matches['id'], "$baseUrl/asset?id={$matches['id']}")
                    : $hyperlink($matches['id'], "$baseUrl/$controller/{$matches['id']}"));
                }, $message, -1, $count);
                if ($count) {
                    $escapeHtml = false;
                }
            }
        }

        $psrMessage = new PsrMessage($message, $context);
        return $psrMessage
            ->setTranslator($translator)
            // TODO Manage the case where some keys should be escaped and some keys not (may be a security issue when logs are external).
            ->setEscapeHtml($escapeHtml);
    }

    public function context(): array
    {
        return $this->resource->getContext();
    }

    public function created(): DateTime
    {
        return $this->resource->getCreated();
    }

    public function owner(): ?UserRepresentation
    {
        $owner = $this->resource->getOwner();
        return $owner
            ? $this->getAdapter('users')->getRepresentation($owner)
            : null;
    }

    public function job(): ?JobRepresentation
    {
        $job = $this->resource->getJob();
        return $job
            ? $this->getAdapter('jobs')->getRepresentation($job)
            : null;
    }

    /**
     * Check if the job associated to the log is in a living state.
     *
     * Windows is not supported (neither in omeka job anyway).
     *
     * Warning: in some cases, the state is not reliable, because it may be the
     * one of another process.
     *
     * @return bool|null Null if no job, else the pid status of the job.
     */
    public function isJobLiving(): ?bool
    {
        $state = $this->jobState();
        return $state
            ? JobState::STATES[$state]['processing']
            : null;
    }

    /**
     * Get the state of the living job (running or stopping) associated to log.
     *
     * Only pid with a job in progress or stopping can be checked.
     * Windows is not supported (neither in omeka job anyway).
     *
     * Linux states are:
     * - R: Running
     * - S: Interruptible Sleep (Sleep, waiting for event from software)
     * - D: Uninterruptible Sleep (Dead, waiting for signal from hardware)
     * - T: Stopped (Traced)
     * - Z: Zombie
     *
     * Warning: in some cases, the state is not reliable, because it may be the
     * one of another process.
     *
     * @uses \Log\Stdlib\JobState
     *
     * @return string|null Letter of the state of the process or null.
     * Full state name can be retrieved from the constant JobState::STATES.
     */
    public function jobState(): ?string
    {
        // The job representation cannot access to the pid, so use entity.
        $job = $this->resource->getJob();
        if (!$job) {
            return null;
        }
        $jobState = $this->getServiceLocator()->get('Log\JobState');
        return $jobState($job);
    }
}
